import { elements } from "./elements.js";


elements.goToSumAppBtn.addEventListener('click', () =>
{
    window.location.href = '../pages/sum.html'
})